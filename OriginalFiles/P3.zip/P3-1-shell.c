/*                  Virtual Blue-Screen

                "Students take a walk in the park"

This program performs a moving object extraction from one sequence,
and superposes it to another static background. It employs a utility
library for jpeg/frame buffer access, a multi-modal mean library for
dynamic background modeling and foreground extraction, and a roller
utility for area density and blob detection. The blobs are area
filtered and used as a mask layer for foreground transfer to the
target image.

NN April 2011                      <your name here>  */

#include <stdlib.h>
#include <stdio.h>
#include "utils.h"
#include "rollers.h"
#include "mmm.h"

int main(int argc, char *argv[]) {

   char                 Path[128], *SeqName;
   int		        Start, End, Step, N;

   if (argc !=5) {
      fprintf(stderr, "usage: %s seqname start end step\n", argv[0]);
      exit(1);
   }
   SeqName = argv[1];
   if (sscanf(argv[2], "%d", &Start) != 1 || Start < 0 ||
       sscanf(argv[3], "%d", &End) != 1 || End < Start ||
       sscanf(argv[4], "%d", &Step) != 1 || Step < 1) {
      fprintf(stderr, "[%s:%s:%s] are invalid start/end/step numbers\n", argv[2], argv[3], argv[4]);
      exit(1);
   }
   if (InDir("trials", BASE_DIR) == FALSE) {
      if (DEBUG)
         printf("   creating %s ...\n", TRIAL_DIR);
      mkdir(TRIAL_DIR, (S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH));
   }
   if (InDir(SeqName, TRIAL_DIR) == FALSE) {
      sprintf(Path, "%s/%s", TRIAL_DIR, SeqName);
      if (DEBUG)
         printf("   creating %s ...\n", Path);
      mkdir(Path, (S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH));
   }
   for (N = Start + 1; N < End + 1; N += Step) {            // for each frame in sequence
      if (DEBUG)
         printf("   processing frame %05d.jpg ...\n", N);
   }
   exit(0);
}
